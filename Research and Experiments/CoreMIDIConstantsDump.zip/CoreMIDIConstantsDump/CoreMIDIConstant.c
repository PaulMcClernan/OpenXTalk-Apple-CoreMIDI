#include <CoreMIDI/MIDIServices.h>

int main(int argc, char* argv[])
{
    ItemCount t_device_cout = MIDIGetNumberOfDevices();
    CFShow(kMIDIPropertyName);
    CFShow(kMIDIPropertyDisplayName);
    CFShow(kMIDIPropertyManufacturer);
    CFShow(kMIDIPropertyModel);
    CFShow(kMIDIPropertyReceiveChannels);
    CFShow(kMIDIPropertyTransmitChannels);
    CFShow(kMIDIPropertyOffline);
    CFShow(kMIDIPropertyUniqueID);
    CFShow(kMIDIPropertyDeviceID);
    CFShow(kMIDIPropertyConnectionUniqueID);
    CFShow(kMIDIPropertyMaxSysExSpeed);
    CFShow(kMIDIPropertyAdvanceScheduleTimeMuSec);
    CFShow(kMIDIPropertyIsBroadcast);
    CFShow(kMIDIPropertySingleRealtimeEntity);
    CFShow(kMIDIPropertyPrivate);
    CFShow(kMIDIPropertyDriverOwner);
    CFShow(kMIDIPropertyFactoryPatchNameFile);
    CFShow(kMIDIPropertyNameConfiguration);
    CFShow(kMIDIPropertyImage);
    CFShow(kMIDIPropertyDriverVersion);
    CFShow(kMIDIPropertySupportsGeneralMIDI);
    CFShow(kMIDIPropertySupportsMMC);
    CFShow(kMIDIPropertyCanRoute);
    CFShow(kMIDIPropertyReceivesClock);
    CFShow(kMIDIPropertyReceivesMTC);
    CFShow(kMIDIPropertyReceivesNotes);
    CFShow(kMIDIPropertyReceivesProgramChanges);
    CFShow(kMIDIPropertyReceivesBankSelectMSB);
    CFShow(kMIDIPropertyReceivesBankSelectLSB);
    CFShow(kMIDIPropertyTransmitsClock);
    CFShow(kMIDIPropertyTransmitsMTC);
    CFShow(kMIDIPropertyTransmitsNotes);
    CFShow(kMIDIPropertyTransmitsProgramChanges);
    CFShow(kMIDIPropertyTransmitsBankSelectMSB);
    CFShow(kMIDIPropertyTransmitsBankSelectLSB);
    CFShow(kMIDIPropertyPanDisruptsStereo);
    CFShow(kMIDIPropertyIsSampler);
    CFShow(kMIDIPropertyIsDrumMachine);
    CFShow(kMIDIPropertyIsMixer);
    CFShow(kMIDIPropertyIsEffectUnit);
    CFShow(kMIDIPropertyMaxReceiveChannels);
    CFShow(kMIDIPropertyMaxTransmitChannels);
    CFShow(kMIDIPropertyDriverDeviceEditorApp);
    CFShow(kMIDIPropertySupportsShowControl);
    return 0;
}
